# Multi-Currency Crypto Signal Bot
Sends RSI and volume-based crypto trade alerts to Telegram. Runs on Render Web Service for free. Supports BTC, ETH, BNB, SOL.